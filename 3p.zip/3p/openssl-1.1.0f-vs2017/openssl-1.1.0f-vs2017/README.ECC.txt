NOTE: The OpenSSL Software Foundation has executed a sublicense agreement
entitled "Elliptic Curve Cryptography Patent License Agreement" with the
National Security Agency/ Central Security Service Commercial Solutions
Center (NCSC) dated 2010-11-04. That agreement permits implementation and
distribution of software containing features covered by any or all of the
following patents:

1.) U.S. Pat. No. 5,761,305 entitled "Key Agreement and Transport Protocol 
    with Implicit Signatures" issued on June 2, 1998;
2.) Can. Pat. Appl. Ser. No. 2176972 entitled "Key Agreement and Transport 
    Protocol with Implicit Signature and Reduced Bandwidth" filed on May 
    16, 1996;
3.) U.S. Pat. No. 5,889,865 entitled "Key Agreement and Transport Protocol 
    with Implicit Signatures" issued on March 30, 1999;
4.) U.S. Pat. No. 5,896,455 entitled "Key Agreement and Transport Protocol 
    with Implicit Signatures" issued on April 20, 1999;
5.) U.S. Pat. No. 5,933,504 entitled "Strengthened Public Key Protocol" 
    issued on August 3, 1999;
6.) Can. Pat. Appl. Ser. No. 2176866 entitled "Strengthened Public Key 
    Protocol" filed on May 17, 1996;
7.) E.P. Pat. Appl. Ser. No. 96201322.3 entitled "Strengthened Public Key 
    Protocol" filed on May 17, 1996;
8.) U.S. Pat. No. 5,999,626 entitled "Digital Signatures on a Smartcard" 
    issued on December 7, 1999;
9.) Can. Pat. Appl. Ser. No. 2202566 entitled "Digital Signatures on a 
    Smartcard" filed on April 14, 1997;
10.) E.P. Pat. Appl. No. 97106114.8 entitled "Digital Signatures on a 
     Smartcard" filed on April 15, 1997;
11.) U.S Pat. No. 6,122,736 entitled "Key Agreement and Transport Protocol 
     with Implicit Signatures" issued on September 19, 2000;
12.) Can. Pat. Appl. Ser. No. 2174261 entitled "Key Agreement and Transport 
     Protocol with Implicit Signatures" filed on April 16, 1996;
13.) E.P. Pat. Appl. Ser. No. 96105920.1 entitled "Key Agreement and 
     Transport Protocol with Implicit Signatures" filed on April 16, 1996;
14.) U.S. Pat. No. 6,141,420 entitled "Elliptic Curve Encryption Systems" 
     issued on October 31, 2000;
15.) Can. Pat. Appl. Ser. No. 2155038 entitled "Elliptic Curve Encryption 
     Systems" filed on July 31, 1995;
16.) E.P. Pat. Appl. Ser. No. 95926348.4 entitled "Elliptic Curve Encryption 
     Systems" filed on July 31, 1995;
17.) U.S. Pat. No. 6,336,188 entitled "Authenticated Key Agreement" issued 
     on January 1, 2002;
18.) U.S. Pat. No. 6,487,661 entitled "Key Agreement and Transport Protocol" 
     issued on November 26, 2002;
19.) Can. Pat. Appl. Ser. No. 2174260 entitled "Key Agreement and Transport 
     Protocol" filed on April 16, 1996;
20.) E.P. Pat. Appl. Ser. No. 96105921.9 entitled "Key Agreement and 
     Transport Protocol" filed on April 21, 1996;
21.) U.S. Pat. No. 6,563,928 entitled "Strengthened Public Key Protocol" 
     issued on May 13, 2003;
22.) U.S. Pat. No. 6,618,483 entitled "Elliptic Curve Encryption Systems" 
     issued September 9, 2003;
23.) U.S. Pat. Appl. Ser. No. 09/434,247 entitled "Digital Signatures on a 
     Smartcard" filed on November 5, 1999;
24.) U.S. Pat. Appl. Ser. No. 09/558,256 entitled "Key Agreement and 
     Transport Protocol with Implicit Signatures" filed on April 25, 2000;
25.) U.S. Pat. Appl. Ser. No. 09/942,492 entitled "Digital Signatures on a 
     Smartcard" filed on August 29, 2001 and published on July 18, 2002; and,
26.) U.S. Pat. Appl. Ser. No. 10/185,735 entitled "Strengthened Public Key 
     Protocol" filed on July 1, 2000.

